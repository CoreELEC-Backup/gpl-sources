var searchData=
[
  ['toggle_5fbit',['toggle_bit',['../structir__remote.html#afbc1dd399fff0771f4d060fce62cdbfe',1,'ir_remote']]],
  ['toggle_5fbit_5fmask',['toggle_bit_mask',['../structir__remote.html#ad1d35f0da36527d473c7d857231ec739',1,'ir_remote']]],
  ['toggle_5fcode',['toggle_code',['../structir__remote.html#ac80cecb60d0e4e77b01c3044df9d6713',1,'ir_remote']]],
  ['toggle_5fmask',['toggle_mask',['../structir__remote.html#a9744aba55e393727c08815e548a9f836',1,'ir_remote']]],
  ['transmit_5fstate',['transmit_state',['../structir__ncode.html#a29cc93e9a6e908dfe8904db34680ef1f',1,'ir_ncode']]]
];
