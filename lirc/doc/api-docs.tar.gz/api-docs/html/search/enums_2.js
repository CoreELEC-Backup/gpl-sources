var searchData=
[
  ['get_5fgap_5fstatus',['get_gap_status',['../irrecord_8h.html#a5eceb01461235b99ccd3a8ccb49c0ebf',1,'irrecord.h']]]
];
