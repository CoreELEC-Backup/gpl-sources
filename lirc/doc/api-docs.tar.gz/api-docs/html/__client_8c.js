var __client_8c =
[
    [ "PyInit__client", "__client_8c.html#a05409ed22ad8b3664e6bc363b5547d1c", null ],
    [ "ClientMethods", "__client_8c.html#a745bcc1d1fc5dbcb988fb96f99b253fa", null ]
];