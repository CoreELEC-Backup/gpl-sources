var searchData=
[
  ['ciniparser',['Ciniparser',['../group__ciniparser.html',1,'']]],
  ['client_20api_20manual_20excerpt_2e',['Client API manual excerpt.',['../group__client__manual.html',1,'']]],
  ['commands_20to_20control_20lircd',['Commands to control lircd',['../group__commands.html',1,'']]],
  ['client_20api',['Client API',['../group__lirc__client.html',1,'']]],
  ['commands_20to_20control_20lircrcd',['Commands to control lircrcd',['../group__lircrcd.html',1,'']]],
  ['classes_20to_20receive_20keypresses',['Classes to receive keypresses',['../group__receiving.html',1,'']]],
  ['classes_20to_20send_20commands',['Classes to send commands',['../group__sending.html',1,'']]]
];
