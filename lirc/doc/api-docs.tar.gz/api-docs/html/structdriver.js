var structdriver =
[
    [ "api_version", "structdriver.html#a16e4dc8d1f027390afd91294991d932d", null ],
    [ "close_func", "structdriver.html#aea9a20decd81cb165101823a40fd29af", null ],
    [ "code_length", "structdriver.html#a46c80e7c710d4222fa41cc6af819e066", null ],
    [ "decode_func", "structdriver.html#a4c8fb1671a48fb248bc8dafa90cded15", null ],
    [ "deinit_func", "structdriver.html#a87fb83240c2426874349f860fb8504dc", null ],
    [ "device", "structdriver.html#aca3bbacc48c5f27dac5568bd658afec8", null ],
    [ "device_hint", "structdriver.html#ab4d02011a73f1778b63c70f45f3ab98b", null ],
    [ "driver_version", "structdriver.html#a2c48ed8680d2f242dd0c018f846551b7", null ],
    [ "drvctl_func", "structdriver.html#ac5d035961037ecb0a74182dd456ced26", null ],
    [ "fd", "structdriver.html#a277e91c9ef0365654b5412cdcf8cac5f", null ],
    [ "features", "structdriver.html#a551a50b0badb7c038dbea018038637e8", null ],
    [ "info", "structdriver.html#a6b71523700af552255b059ff51a657e1", null ],
    [ "init_func", "structdriver.html#a8f50bcc4e1d143a05dd4eba66a4fa7bb", null ],
    [ "name", "structdriver.html#a2d4bc5861fb0d7bb1684e22a16b7d414", null ],
    [ "open_func", "structdriver.html#aeea866dd70c1cb8296e99fbe706bacf5", null ],
    [ "readdata", "structdriver.html#a6dc74317e7f5fff8153be89153766865", null ],
    [ "rec_func", "structdriver.html#a41e193204b057873b878b1979c309db8", null ],
    [ "rec_mode", "structdriver.html#af26686923a5a786e47b5c39f3fd25399", null ],
    [ "resolution", "structdriver.html#a91eef0a66c9eb8ba1d3c8c9f69a1086b", null ],
    [ "send_func", "structdriver.html#a90d38db70255ee7d38bcd81c9edd9412", null ],
    [ "send_mode", "structdriver.html#a3242a5145451f5693492e88286b5bab3", null ]
];