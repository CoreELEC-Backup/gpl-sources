var lirc_utils_8c =
[
    [ "drop_root_cli", "group__private__api.html#ga24f983a41e2fccf1c7ba3ee4d69559a4", null ],
    [ "drop_sudo_root", "group__private__api.html#ga08cad0a0a22fb34e70ef33be007e484d", null ]
];