var classlirc_1_1client_1_1AbstractConnection =
[
    [ "__enter__", "classlirc_1_1client_1_1AbstractConnection.html#a1fd7f22869b673c708b6d480a302b59d", null ],
    [ "__exit__", "classlirc_1_1client_1_1AbstractConnection.html#a4f27c8173812f53b642b14cc7a995b6d", null ],
    [ "close", "classlirc_1_1client_1_1AbstractConnection.html#a4f8bd401740bb01d15a0e29b700ca2d3", null ],
    [ "fileno", "classlirc_1_1client_1_1AbstractConnection.html#a73ec9f73d3b75369a6472d1cd097ab74", null ],
    [ "has_data", "classlirc_1_1client_1_1AbstractConnection.html#a862046d41c4b3c20b85a779cde62cd9d", null ],
    [ "readline", "classlirc_1_1client_1_1AbstractConnection.html#a2c96badca6167e644e01f642d3380b5d", null ]
];