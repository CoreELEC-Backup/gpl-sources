var searchData=
[
  ['goldstar',['GOLDSTAR',['../ir__remote__types_8h.html#ac3574bc899d70e66c326f73fd8b4b671',1,'ir_remote_types.h']]],
  ['grundig',['GRUNDIG',['../ir__remote__types_8h.html#a40b8ce019aff9658b6afb245bc26b8eb',1,'ir_remote_types.h']]]
];
