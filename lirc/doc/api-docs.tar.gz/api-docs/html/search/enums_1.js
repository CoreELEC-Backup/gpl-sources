var searchData=
[
  ['button_5fstatus',['button_status',['../irrecord_8h.html#a3ba15f6896e40b9ba6c5bf1d398dab4a',1,'irrecord.h']]]
];
