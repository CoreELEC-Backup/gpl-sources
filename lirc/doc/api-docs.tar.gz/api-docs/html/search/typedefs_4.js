var searchData=
[
  ['plugin_5fguest_5ffunc',['plugin_guest_func',['../drv__admin_8h.html#a061d49469cbffaa34c2b73062a2607ab',1,'drv_admin.h']]]
];
