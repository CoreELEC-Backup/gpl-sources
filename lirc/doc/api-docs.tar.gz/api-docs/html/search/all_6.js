var searchData=
[
  ['fd',['fd',['../structdriver.html#a277e91c9ef0365654b5412cdcf8cac5f',1,'driver']]],
  ['features',['features',['../structdriver.html#a551a50b0badb7c038dbea018038637e8',1,'driver']]],
  ['feed',['feed',['../classlirc_1_1client_1_1ReplyParser.html#a533771ce7f2f69451a5076a4a1680ef4',1,'lirc::client::ReplyParser']]],
  ['fileno',['fileno',['../classlirc_1_1client_1_1AbstractConnection.html#a73ec9f73d3b75369a6472d1cd097ab74',1,'lirc.client.AbstractConnection.fileno()'],['../classlirc_1_1client_1_1RawConnection.html#a94fd44d2010ad66c67106dffb36a4137',1,'lirc.client.RawConnection.fileno()'],['../classlirc_1_1client_1_1LircdConnection.html#a0d4ebca3446a605deb6aedf6756f6421',1,'lirc.client.LircdConnection.fileno()']]],
  ['find_5fconfig',['find_config',['../classlirc_1_1database_1_1Database.html#a7219fd90c7d6ea27db55fa3ffe12a824',1,'lirc::database::Database']]],
  ['flag',['flag',['../structflaglist.html#afe3283978a321862c7c7705e13206672',1,'flaglist']]],
  ['flaglist',['flaglist',['../structflaglist.html',1,'']]],
  ['flags',['flags',['../structir__remote.html#a9ac03eb6d4cee793010b00fe434aa985',1,'ir_remote']]],
  ['flushhw',['flushhw',['../irrecord_8c.html#a198cace7ef605b777b3e14fc8289426b',1,'flushhw(void):&#160;irrecord.c'],['../irrecord_8h.html#a198cace7ef605b777b3e14fc8289426b',1,'flushhw(void):&#160;irrecord.c']]],
  ['for_5feach_5fdriver',['for_each_driver',['../drv__admin_8c.html#a20c8785b0c4a112a87b05eec158ecef7',1,'for_each_driver(drv_guest_func func, void *arg, const char *pluginpath):&#160;drv_admin.c'],['../drv__admin_8h.html#a20c8785b0c4a112a87b05eec158ecef7',1,'for_each_driver(drv_guest_func func, void *arg, const char *pluginpath):&#160;drv_admin.c']]],
  ['for_5feach_5fplugin',['for_each_plugin',['../drv__admin_8c.html#aac333496b18370092de4b8a1efde53d5',1,'for_each_plugin(plugin_guest_func plugin_guest, void *arg, const char *pluginpath):&#160;drv_admin.c'],['../drv__admin_8h.html#aac333496b18370092de4b8a1efde53d5',1,'for_each_plugin(plugin_guest_func plugin_guest, void *arg, const char *pluginpath):&#160;drv_admin.c']]],
  ['for_5feach_5fremote',['for_each_remote',['../irrecord_8c.html#aeeb91096305a1eae213eba243cb6d197',1,'for_each_remote(struct ir_remote *remotes, remote_func func):&#160;irrecord.c'],['../irrecord_8h.html#aeeb91096305a1eae213eba243cb6d197',1,'for_each_remote(struct ir_remote *remotes, remote_func func):&#160;irrecord.c']]],
  ['free_5fall_5flengths',['free_all_lengths',['../irrecord_8c.html#ac048f7ba69dba23c70e40057961428be',1,'free_all_lengths(void):&#160;irrecord.c'],['../irrecord_8h.html#ac048f7ba69dba23c70e40057961428be',1,'free_all_lengths(void):&#160;irrecord.c']]],
  ['free_5fconfig',['free_config',['../group__private__api.html#gaa55b7dcba60df4c178fd885eaf129288',1,'free_config(struct ir_remote *remotes):&#160;config_file.c'],['../group__private__api.html#gaa55b7dcba60df4c178fd885eaf129288',1,'free_config(struct ir_remote *remotes):&#160;config_file.c']]],
  ['freq',['freq',['../structir__remote.html#a04eb04a7c2333f53ceb20ffef8d2ebc4',1,'ir_remote']]]
];
