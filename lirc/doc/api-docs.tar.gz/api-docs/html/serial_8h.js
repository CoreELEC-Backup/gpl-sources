var serial_8h =
[
    [ "tty_clear", "group__driver__api.html#gaa680ad6c63aaac541fc85d61b73a46d1", null ],
    [ "tty_create_lock", "group__driver__api.html#gaa2128e719d5174e1210fcc8c532c82bd", null ],
    [ "tty_delete_lock", "group__driver__api.html#ga94d6aff1542d08fcf32b5acdc735090e", null ],
    [ "tty_read", "group__driver__api.html#ga76ea8c360d88f108399c5926b3bff16d", null ],
    [ "tty_reset", "group__driver__api.html#ga2cad04de039521ac1b0c14c42ba1b43c", null ],
    [ "tty_set", "group__driver__api.html#ga17fb600e510ec6919659e7fab74c3de6", null ],
    [ "tty_setbaud", "group__driver__api.html#ga44b60aca788c92e31b61298f534d2b2c", null ],
    [ "tty_setcsize", "group__driver__api.html#gaffeab51b57e1e8eaca6fc502f99e6c29", null ],
    [ "tty_setdtr", "group__driver__api.html#ga7c9acb60305177b4498553782eb4fa3c", null ],
    [ "tty_setrtscts", "group__driver__api.html#gafcab1b890be0e097640ff31f866ab94c", null ],
    [ "tty_write", "group__driver__api.html#ga03233443b447b2de3a81b77a317663c4", null ],
    [ "tty_write_echo", "group__driver__api.html#ga855e6cb4247f8359643a184a912d754d", null ]
];