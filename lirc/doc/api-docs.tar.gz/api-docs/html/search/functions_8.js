var searchData=
[
  ['invert_5fdata',['invert_data',['../irrecord_8c.html#aa5e67a97a90ea1dc854345f69d7661c7',1,'invert_data(struct ir_remote *remote):&#160;irrecord.c'],['../irrecord_8h.html#aa5e67a97a90ea1dc854345f69d7661c7',1,'invert_data(struct ir_remote *remote):&#160;irrecord.c']]],
  ['ir_5fremote_5finit',['ir_remote_init',['../group__driver__api.html#ga8d5bc121b8582a690000bc8befe13080',1,'ir_remote_init(int use_dyncodes):&#160;ir_remote.c'],['../group__driver__api.html#ga8d5bc121b8582a690000bc8befe13080',1,'ir_remote_init(int use_dyncodes):&#160;ir_remote.c']]],
  ['is_5fcompleted',['is_completed',['../classlirc_1_1client_1_1ReplyParser.html#a936b03d03fb58d34eb689d47880a3c48',1,'lirc::client::ReplyParser']]],
  ['is_5fin_5fremotes',['is_in_remotes',['../group__driver__api.html#gaadf09b8ef4b71be00f8e53a39f70d315',1,'is_in_remotes(const struct ir_remote *remotes, const struct ir_remote *remote):&#160;ir_remote.c'],['../group__driver__api.html#gaadf09b8ef4b71be00f8e53a39f70d315',1,'is_in_remotes(const struct ir_remote *remotes, const struct ir_remote *remote):&#160;ir_remote.c']]]
];
