var classlirc_1_1client_1_1Command =
[
    [ "__init__", "classlirc_1_1client_1_1Command.html#ac68f1cb7338ecb3af5705e21031ff6cd", null ],
    [ "run", "classlirc_1_1client_1_1Command.html#ab9e989920c1f77076b92dee5ff1133af", null ]
];