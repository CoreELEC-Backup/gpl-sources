var searchData=
[
  ['packet_5fsize',['PACKET_SIZE',['../lirc__config_8h.html#aebdc7d8ca8e25ed8efc90bb88ef7ef5b',1,'lirc_config.h']]],
  ['pid_5flircd',['PID_LIRCD',['../lirc__config_8h.html#ae6cce9a1de2af2a20056fbf342ab73c6',1,'lirc_config.h']]],
  ['pidfile',['PIDFILE',['../lirc__config_8h.html#af5fe208f8640c8c789a4d5d5b8ad47f5',1,'lirc_config.h']]],
  ['plugindir',['PLUGINDIR',['../lirc__config_8h.html#aab5f12bd566916ffe7b907ab31a0d105',1,'lirc_config.h']]],
  ['plugindir_5fvar',['PLUGINDIR_VAR',['../lirc__config_8h.html#acd7e7944bfb1c0b9676d9ffad6b0486c',1,'lirc_config.h']]]
];
