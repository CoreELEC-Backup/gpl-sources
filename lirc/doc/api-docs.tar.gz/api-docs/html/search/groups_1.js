var searchData=
[
  ['driver_20api_20manual_20excerpt',['Driver API manual excerpt',['../group__driver__manual.html',1,'']]]
];
