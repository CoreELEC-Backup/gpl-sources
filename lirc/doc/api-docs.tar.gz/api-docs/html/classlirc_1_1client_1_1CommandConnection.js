var classlirc_1_1client_1_1CommandConnection =
[
    [ "__init__", "classlirc_1_1client_1_1CommandConnection.html#a31e077bbdaacad8fdad87e982a81d677", null ],
    [ "send", "classlirc_1_1client_1_1CommandConnection.html#a84d8a06969fb4e2eec59f835cb616e5b", null ]
];