var searchData=
[
  ['kernel_5fdrivers',['kernel_drivers',['../classlirc_1_1database_1_1Database.html#aea621bb5f1c278b60461fe72d01e7d20',1,'lirc::database::Database']]],
  ['keypresses',['keypresses',['../structlengths__state.html#a5ba133f3076964dba14d621d8be2a335',1,'lengths_state']]],
  ['keypresses_5fdone',['keypresses_done',['../structlengths__state.html#a2044804fca25b7d5daa57bbc3a44605a',1,'lengths_state']]]
];
