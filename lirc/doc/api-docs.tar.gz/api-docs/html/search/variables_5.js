var searchData=
[
  ['fd',['fd',['../structdriver.html#a277e91c9ef0365654b5412cdcf8cac5f',1,'driver']]],
  ['features',['features',['../structdriver.html#a551a50b0badb7c038dbea018038637e8',1,'driver']]],
  ['flag',['flag',['../structflaglist.html#afe3283978a321862c7c7705e13206672',1,'flaglist']]],
  ['flags',['flags',['../structir__remote.html#a9ac03eb6d4cee793010b00fe434aa985',1,'ir_remote']]],
  ['freq',['freq',['../structir__remote.html#a04eb04a7c2333f53ceb20ffef8d2ebc4',1,'ir_remote']]]
];
